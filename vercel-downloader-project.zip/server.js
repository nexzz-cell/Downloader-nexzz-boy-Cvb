const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();

const PORT = process.env.SERVER_PORT || process.env.PORT || 3000;
const UPLOAD_DIR = path.join(__dirname, "uploads");
const MAX_FILE_SIZE_MB = process.env.MAX_FILE_SIZE_MB
  ? parseInt(process.env.MAX_FILE_SIZE_MB)
  : 200;

if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const timestamp = Date.now();
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, "_");
    cb(null, `${timestamp}-${safeName}`);
  },
});

const upload = multer({
  storage: storage,
  limits: { fileSize: MAX_FILE_SIZE_MB * 1024 * 1024 },
});

app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));

function formatSize(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  if (bytes < 1024 * 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + " MB";
  return (bytes / 1024 / 1024 / 1024).toFixed(1) + " GB";
}

app.get("/", (req, res) => {
  fs.readdir(UPLOAD_DIR, (err, files) => {
    if (err) files = [];

    const fileList = files
      .filter((f) => !f.startsWith("."))
      .map((f) => {
        const stat = fs.statSync(path.join(UPLOAD_DIR, f));
        const originalName = f.substring(f.indexOf("-") + 1);
        return {
          storedName: f,
          displayName: originalName,
          size: formatSize(stat.size),
          date: stat.mtime.toLocaleString("id-ID"),
        };
      })
      .sort((a, b) => (a.date < b.date ? 1 : -1));

    let rows = fileList
      .map(
        (f) => `
        <tr>
          <td>${f.displayName}</td>
          <td>${f.size}</td>
          <td>${f.date}</td>
          <td>
            <a class="btn" href="/download/${encodeURIComponent(f.storedName)}">Download</a>
            <a class="btn btn-danger" href="/delete/${encodeURIComponent(f.storedName)}" onclick="return confirm('Hapus file ini?')">Hapus</a>
          </td>
        </tr>`
      )
      .join("");

    if (fileList.length === 0) {
      rows = `<tr><td colspan="4" class="empty">Belum ada file yang diupload</td></tr>`;
    }

    res.send(`<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Upload File</title>
<style>
  * { box-sizing: border-box; }
  body {
    font-family: Arial, Helvetica, sans-serif;
    background: #0f172a;
    color: #e2e8f0;
    margin: 0;
    padding: 30px 15px;
  }
  .container {
    max-width: 900px;
    margin: 0 auto;
  }
  h1 {
    text-align: center;
    margin-bottom: 5px;
  }
  p.subtitle {
    text-align: center;
    color: #94a3b8;
    margin-top: 0;
    margin-bottom: 30px;
  }
  .upload-box {
    background: #1e293b;
    border: 1px dashed #334155;
    border-radius: 10px;
    padding: 25px;
    text-align: center;
    margin-bottom: 30px;
  }
  input[type="file"] {
    margin-bottom: 15px;
    color: #e2e8f0;
  }
  button {
    background: #2563eb;
    color: #fff;
    border: none;
    padding: 10px 25px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 15px;
  }
  button:hover {
    background: #1d4ed8;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    background: #1e293b;
    border-radius: 10px;
    overflow: hidden;
  }
  th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #334155;
    font-size: 14px;
  }
  th {
    background: #111827;
    color: #93c5fd;
  }
  .empty {
    text-align: center;
    color: #64748b;
    padding: 25px;
  }
  .btn {
    display: inline-block;
    padding: 6px 12px;
    background: #16a34a;
    color: #fff;
    border-radius: 5px;
    text-decoration: none;
    font-size: 13px;
    margin-right: 5px;
  }
  .btn:hover {
    background: #15803d;
  }
  .btn-danger {
    background: #dc2626;
  }
  .btn-danger:hover {
    background: #b91c1c;
  }
  .info {
    text-align: center;
    color: #64748b;
    font-size: 13px;
    margin-top: 20px;
  }
</style>
</head>
<body>
  <div class="container">
    <h1>Upload File</h1>
    <p class="subtitle">File yang diupload dapat didownload oleh semua orang</p>

    <div class="upload-box">
      <form action="/upload" method="POST" enctype="multipart/form-data">
        <input type="file" name="file" required>
        <br>
        <button type="submit">Upload File</button>
      </form>
    </div>

    <table>
      <thead>
        <tr>
          <th>Nama File</th>
          <th>Ukuran</th>
          <th>Tanggal Upload</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        ${rows}
      </tbody>
    </table>

    <p class="info">Batas ukuran file: ${MAX_FILE_SIZE_MB} MB per file</p>
  </div>
</body>
</html>`);
  });
});

app.post("/upload", upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).send("Tidak ada file yang diupload");
  }
  res.redirect("/");
});

app.get("/download/:filename", (req, res) => {
  const filePath = path.join(UPLOAD_DIR, req.params.filename);
  if (!fs.existsSync(filePath)) {
    return res.status(404).send("File tidak ditemukan");
  }
  const originalName = req.params.filename.substring(
    req.params.filename.indexOf("-") + 1
  );
  res.download(filePath, originalName);
});

app.get("/delete/:filename", (req, res) => {
  const filePath = path.join(UPLOAD_DIR, req.params.filename);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }
  res.redirect("/");
});

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).send("Upload gagal: " + err.message);
  } else if (err) {
    return res.status(500).send("Terjadi kesalahan server");
  }
  next();
});

app.listen(PORT, () => {
  console.log(`Server berjalan di port ${PORT}`);
});
