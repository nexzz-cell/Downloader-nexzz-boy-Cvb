# Vercel Downloader

Project ini sudah disiapkan untuk deployment ke Vercel.

## Struktur
- `public/` = website/frontend
- `api/` = Vercel Serverless Functions
- `vercel.json` = konfigurasi Vercel
- `uploads/` = folder lama dari project. Jangan gunakan sebagai penyimpanan permanen di Vercel.

## Deploy
Import project ini ke Vercel. Setelah deploy, website bisa diakses publik melalui domain `*.vercel.app`.

## Catatan upload
Vercel bukan hosting disk permanen. File yang di-upload ke filesystem function tidak boleh dianggap tersimpan permanen.
Untuk downloader publik dengan upload permanen, gunakan object storage seperti:
- Supabase Storage
- Cloudflare R2
- Vercel Blob

API dasar sudah tersedia di `/api`.
