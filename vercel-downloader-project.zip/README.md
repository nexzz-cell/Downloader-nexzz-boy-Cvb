# Website Upload File - Pterodactyl Panel

Website sederhana untuk upload file dan bisa didownload oleh semua orang. Dibuat pakai Node.js + Express, siap dijalankan di Pterodactyl Panel.

## Isi Folder

- `server.js` - kode utama aplikasi
- `package.json` - daftar dependency
- `egg-website-upload-file.json` - egg untuk diimport ke Pterodactyl
- `uploads/` - folder tempat file hasil upload disimpan (dibuat otomatis)

## Cara Pasang di Pterodactyl Panel

### 1. Import Egg
1. Masuk ke Admin Area di Pterodactyl Panel.
2. Buka menu Nests, lalu pilih Import Egg (atau buat Nest baru dulu bila belum ada).
3. Upload file `egg-website-upload-file.json`.
4. Egg akan muncul dengan nama "Website Upload File".

### 2. Buat Server Baru
1. Buka menu Servers, klik Create New.
2. Pilih Nest dan Egg "Website Upload File".
3. Pilih Docker Image "Node.js 20".
4. Atur Allocation (port) sesuai kebutuhan, misal 3000.
5. Isi variable "Server Port" sama dengan port allocation yang dipilih.
6. Isi variable "Batas Ukuran File (MB)" sesuai keinginan, contoh 200.
7. Klik Create Server.

### 3. Upload Source Code
1. Setelah server dibuat, buka tab File Manager server tersebut.
2. Upload file `server.js`, `package.json`, dan folder `public` (jika ada) ke root direktori server.
3. Buka tab Console, tekan tombol Start.
4. Panel akan otomatis menjalankan `npm install` lalu `node server.js`.

### 4. Akses Website
Buka browser ke alamat `http://IP-SERVER:PORT`, contoh `http://45.xx.xx.xx:3000`.

## Fitur

- Upload file lewat halaman utama.
- Daftar file yang sudah diupload beserta ukuran dan tanggal.
- Tombol Download untuk setiap file, bisa diakses siapa saja tanpa login.
- Tombol Hapus untuk membuang file dari server.
- Batas ukuran file bisa diatur lewat variable egg.

## Catatan Keamanan

Website ini tidak memakai sistem login, jadi siapa saja yang tahu alamatnya bisa upload dan download file. Kalau butuh dibatasi, tambahkan autentikasi sederhana (misal HTTP Basic Auth) sebelum dipakai untuk data yang sensitif.
