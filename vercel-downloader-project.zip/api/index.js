module.exports = (req, res) => {
  res.status(200).json({
    ok: true,
    service: "Vercel Downloader API",
    message: "API aktif. Untuk penyimpanan file permanen, hubungkan storage eksternal seperti Supabase Storage, Cloudflare R2, atau Vercel Blob."
  });
};
